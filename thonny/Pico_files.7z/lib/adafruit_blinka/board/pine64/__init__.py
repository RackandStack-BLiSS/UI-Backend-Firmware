# SPDX-FileCopyrightText: 2024 Chris Brown
#
# SPDX-License-Identifier: MIT
"""Board definitions from Pine64"""
