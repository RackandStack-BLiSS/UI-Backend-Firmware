#SPDX-FileCopyrightText: 2024 Liz Clark for Adafruit Industries
#
#SPDX-License-Identifier: MIT

"""HDC302x simple test"""
import time
import board
import adafruit_scd4x
import adafruit_hdc302x
import adafruit_bmp3xx
import busio

scl = board.GP1
sda = board.GP0
i2c = busio.I2C(scl,sda) # uses board.SCL and board.SDA
scd4x = adafruit_scd4x.SCD4X(i2c)
hdc302x = adafruit_hdc302x.HDC302x(i2c)
bmp3xx = adafruit_bmp3xx.BMP3XX_I2C(i2c) 

print("Serial number:", [hex(i) for i in scd4x.serial_number])

scd4x.start_periodic_measurement()
print("Waiting for first measurement....")
first = True

bmp3xx.sea_level_pressure = 1019
while True:
    if scd4x.data_ready:
        current_time = time.time()
        if first:
            start_time = current_time
            first = False
        print(f"Timestamp: {(current_time - start_time)}")
        #print("CO2: %d ppm" % scd4x.CO2)
        #print("bmp Temperature: {:5.2f} °C".format(bmp3xx.temperature))
        print(f"hdc Temperature: {hdc302x.temperature:0.1f}°C")
        print(f"Relative Humidity: {hdc302x.relative_humidity:0.1f}%")
        #print("Temperature: %0.1f *C" % scd4x.temperature)
        #print("Humidity: %0.1f %%" % scd4x.relative_humidity)
        print()
    #print("Pressure: {:6.1f}".format(bmp3xx.pressure))
    
    #print("Altitude: {} meters".format(bmp3xx.altitude))
    

    time.sleep(5)
